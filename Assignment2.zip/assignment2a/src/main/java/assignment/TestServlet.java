package assignment;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestServlet
 */
@WebServlet("/TestServlet")
public class TestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String firstName;
	private String lastName;
	
	@Override
	public void init() 
	{
		System.out.println("Initialize");
	}
	
	@Override
	public void destroy() 
	{
		System.out.println("Destroy");
	}
       
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestServlet()
    {
        super();
        // TODO Auto-generated constructor stub
    }

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		firstName = request.getParameter("first");
		lastName = request.getParameter("last");
		System.out.println("doGet");
		if(firstName == null && lastName == null)
		{
			 System.out.println("Inputs are null");
			 return;
		}
		
		System.out.println(firstName);
		System.out.println(lastName);

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
